import type { AccountSecret } from '../wallet-layer-arkade/account.ts';
import type { BisAssets } from './asset-presentation.ts';
import type { BisAsset } from './assets.ts';
import type { TestNetwork } from './test-network.ts';

type AssetState = Readonly<{ profileId?: string; network?: string; assets: BisAssets }>;
type AssetIdentity = Readonly<{ version: number; profileId?: string }>;

export type AssetViewLifecycleOptions = Readonly<{
  getState(): AssetState;
  getIdentity(): AssetIdentity;
  isDisposed(): boolean;
  isVisible(): boolean;
  readSnapshot(signal: AbortSignal, force?: boolean): Promise<{ assets: readonly BisAsset[] }>;
  invalidate?(): void;
  setAssets(assets: BisAssets): void;
  loadAccount(): Promise<{ account?: AccountSecret | null }>;
  observeAssets?(account: AccountSecret, signal: AbortSignal, changed: () => void): Promise<void>;
}>;

/** Owns only the visible asset snapshot/watch lifecycle; the context retains public state ownership. */
export function createAssetViewLifecycle(options: AssetViewLifecycleOptions) {
  const idleAssets: BisAssets = Object.freeze({status:'idle'});
  let watch = new AbortController();
  let refreshPending = false;
  let read: Promise<void> | undefined;
  let version = 0;
  let operation = new AbortController();
  const cancel = () => { version++; operation.abort(); operation = new AbortController(); };

  async function refresh(background = false, force = false): Promise<void> {
    if (!options.isVisible()) return;
    if (read) { if (background) refreshPending = true; return read; }
    const work = async () => {
      do {
        refreshPending = false;
        cancel();
        const request = version;
        const identity = options.getIdentity();
        const signal = operation.signal;
        const current = () => !options.isDisposed() && !signal.aborted && request === version && identity.version === options.getIdentity().version && identity.profileId === options.getIdentity().profileId && options.isVisible();
        if (!background || options.getState().assets.status !== 'ready') options.setAssets(Object.freeze({status:'loading'}));
        try {
          const result = await options.readSnapshot(signal, force || background);
          if (current()) {
            options.setAssets(Object.freeze({status:'ready', ...(background ? {background:true} : {}), assets:result.assets}));
          }
        } catch {
          if (current() && !refreshPending) options.setAssets(Object.freeze({status:'unavailable'}));
        }
        if (!current()) break;
      } while (refreshPending);
    };
    const active = work(); read = active;
    try { await active; } finally { if (read === active) read = undefined; }
  }

  function reset() {
    watch.abort();
    watch = new AbortController();
    read = undefined;
    refreshPending = false;
    cancel();
  }

  function startWatch() {
    if (!options.observeAssets) return;
    const signal = watch.signal;
    const profile = options.getState().profileId;
    const network = options.getState().network ?? 'signet';
    if (network !== 'signet' && network !== 'mutinynet') return;
    void (async () => {
      const saved = await options.loadAccount();
      if (signal.aborted || options.isDisposed() || !saved.account || saved.account.profileId !== profile || (options.getState().network ?? 'signet') !== network || (saved.account.network !== undefined && saved.account.network !== network)) return;
      await options.observeAssets!({...saved.account, network: network as TestNetwork}, signal, () => {
        if (!signal.aborted && !options.isDisposed() && options.getState().profileId === profile && (options.getState().network ?? 'signet') === network && options.isVisible()) { options.invalidate?.(); void refresh(true); }
      });
    })().catch(() => { /* Manual refresh remains available if streaming is unavailable. */ });
  }

  function beginVisibleSession() {
    queueMicrotask(() => {
      if (!options.isDisposed() && options.isVisible() && options.getState().assets.status === 'idle') {
        void refresh();
        startWatch();
      }
    });
  }

  return Object.freeze({ idleAssets, refresh, reset, startWatch, beginVisibleSession, session: () => version });
}
